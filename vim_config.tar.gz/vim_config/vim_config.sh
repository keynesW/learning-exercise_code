#!/bin/bash

sudo apt-get install vim

cp ./vim.tar.gz $HOME 

cd $HOME

cp $HOME/.vimrc $HOME/.vimrc_bak

tar zxvf $HOME/vim.tar.gz

rm -rf $HOME/vim.tar.gz
